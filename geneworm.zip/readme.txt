Scripted Gene Worm Boss V1.00

In of6a4b the final button have been modified
to activate the elevator that brings you to of6a5.

In of6a5 awaits you the scripted Boss-Battle Gene Worm.
This Gene Worm will differ from the original game Opposing Force a little bit.

The Attacks are: Melee-Attack, Poison Gas,
spawning Enemies and destroying their surrounding.
To beat the Boss you have to attack their Eyes to enable access to the Heart,
then attack the Heart to damage the Boss.
Repeat the process several times, to defeat the Boss.

After the Boss gets defeated, the next map (of7a0) get loaded
to show the ending of the Opposing Force Campaign.

Installation:
Extract this zip-file into Sven Co-op/svencoop_addon/

Credits:
Scripts and modifications by CubeMath
Opposing Force by Gearbox and Valve

Known Bugs:
Bosses and the Poison gas Hitbox might be a little inaccurate.

Contact:
http://steamcommunity.com/id/CubeMath/
https://discord.gg/4aYW2wx
