Map disco_boss - Disconator

Can you beat this challenging map in Survival-Mode?
The Difficulty is very hard and requires alot of Skill.
Avoid Fireballs, Lasers and electric red Disco-Floor-Tiles and
Throw your Grenades at the Disconator-Boss to damage and beat it.

This Boss-Battle is splitted in 4 Phases.

Phase 1:
The Disconator throws Fireballs at you.

Phase 2:
The Disco-Floor begins to Flash.
These Disco-Floor-Tiles have pretty simple Rules like a Traffic-Light.
Red Disco-Floor-Tiles will hurt you.
Yellow Disco-Floor-Tiles are safe but gonna turn red on next Beat.
Green Disco-Floor-Tiles are safe.
Also the Disconator gonna throw faster.

Phase 3:
Lasers will appear on the map and rotates around the Arena.
The Disco-Floor will flash faster.
And the Disconator pretty much spams his attack on the Players.

Phase 4:
More Lasers appears on the map and rotates around the Arena.
The Disco-Floor will flash a little bit faster.
And the Disconator is pretty much damaged and activated his Rage-Mode.
The Boss rotates and throw randomly his Fireballs on the Arena.

Drone:
A Drone is flying around the map and drops Grenade-Ammo on the Floor.
Bug: The Drone is suppoust to find People with lowest
Grenade-Ammo-Amount and drops Grenades near them.

Dynamic-Health-System:
More People playing the map means more Health for the Disconator.

Credits:
Map by CubeMath
Disconator-Model by CubeMath

Music:
Super Mario 64 - Puzzle Solved Jingle
Hell-Yeah! Wrath of the Dead Rabbit - Movyaboday
Hell-Yeah! Wrath of the Dead Rabbit - Tekno Kidz
Hell-Yeah! Wrath of the Dead Rabbit - Brutal Kombat
Hell-Yeah! Wrath of the Dead Rabbit - The Chase

Known Bugs:
Visual - Lasers might be difficult to see
Minor - Drone doesn't drop Grenades above the Players, who doesn't have any Grenades

Contact:
http://steamcommunity.com/id/CubeMath/
https://discord.gg/4aYW2wx
